Jobly.configure do |config|
  config.jobs_namespace = 'Jobs'
end
