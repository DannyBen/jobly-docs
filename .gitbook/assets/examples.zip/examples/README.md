# Examples

{% file src="../.gitbook/assets/examples.zip" caption="Download Examples Folder" %}

Each folder contains annotated example files and a README with further explanations or commands to try out.

It is recommended that you view the [01-minimal](https://github.com/DannyBen/jobly-docs/tree/5ff4d0bada505a692c2130172e3d0999a55d4bbe/examples/01-minimal/README.md) and [02-full](https://github.com/DannyBen/jobly-docs/tree/5ff4d0bada505a692c2130172e3d0999a55d4bbe/examples/02-full/README.md) examples first, before continuing to the topical examples.

